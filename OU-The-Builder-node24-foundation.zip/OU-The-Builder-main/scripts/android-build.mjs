import { existsSync, chmodSync } from 'node:fs';
import { resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import process from 'node:process';

const repoRoot = resolve(import.meta.dirname, '..');
const projectDir = resolve(repoRoot, 'OU_The_Builder_Foundation');
const wrapper = process.platform === 'win32' ? 'gradlew.bat' : 'gradlew';
const wrapperPath = resolve(projectDir, wrapper);
const task = process.argv[2] ?? 'assembleDebug';

const major = Number.parseInt(process.versions.node.split('.')[0], 10);
if (major !== 24) {
  console.error(`ERROR: OU The Builder requires Node.js 24.x. Detected Node.js ${process.version}.`);
  process.exit(1);
}

if (!existsSync(projectDir)) {
  console.error(`ERROR: Android project directory not found: ${projectDir}`);
  process.exit(1);
}

if (!existsSync(wrapperPath)) {
  console.error(`ERROR: Gradle wrapper not found: ${wrapperPath}`);
  process.exit(1);
}

if (process.platform !== 'win32') {
  chmodSync(wrapperPath, 0o755);
}

const args = [task, '--stacktrace', '--no-daemon'];
console.log(`Node.js ${process.version}`);
console.log(`Android project: ${projectDir}`);
console.log(`Running: ${wrapper} ${args.join(' ')}`);

const result = spawnSync(wrapperPath, args, {
  cwd: projectDir,
  env: process.env,
  stdio: 'inherit'
});

if (result.error) {
  console.error(`ERROR: Unable to start Gradle wrapper: ${result.error.message}`);
  process.exit(1);
}

if (result.status !== 0) {
  process.exit(result.status ?? 1);
}
